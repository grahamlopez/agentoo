from pathlib import Path
import json
import shutil
import subprocess
import time

def read(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None

def counters():
    paths = list(Path('/sys/class/drm/card0/gt').glob('gt*/rc6_residency_ms'))
    paths += list(Path('/sys/class/powercap').glob('intel-rapl:*/energy_uj'))
    return {str(p): int(value) for p in paths if (value := read(p)) is not None}

def devices():
    return {p.name: {n: read(p / 'power' / n) for n in ('control', 'runtime_status')}
            for p in sorted(Path('/sys/bus/pci/devices').glob('*'))}

def nvme_command(args):
    try:
        result = subprocess.run(['nvme', *args], capture_output=True,
                                text=True, timeout=10)
        return {'returncode': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr}
    except subprocess.TimeoutExpired:
        return {'error': 'NVMe diagnostic command timed out after 10 seconds'}

report = {'boot_id': read('/proc/sys/kernel/random/boot_id'),
          'uptime': read('/proc/uptime'), 'devices': devices(),
          'package_before': read('/sys/kernel/debug/pmc_core/package_cstate_show')}
start = counters()
started = time.monotonic()
watts = []
for _ in range(10):
    b = Path('/sys/class/power_supply/BAT0')
    current, voltage = read(b / 'current_now'), read(b / 'voltage_now')
    if current is not None and voltage is not None:
        watts.append(int(current) * int(voltage) / 1e12)
    time.sleep(2)
elapsed = time.monotonic() - started
end = counters()
report['battery_watts'] = watts
report['mean_battery_watts'] = sum(watts) / len(watts) if watts else None
report['rc6_percent'] = {p: round((end[p] - v) / elapsed / 10, 2)
                         for p, v in start.items() if p in end and 'rc6' in p}
report['energy_counter_deltas_uj'] = {p: end[p] - v for p, v in start.items()
                                      if p in end and 'energy_uj' in p}
report['elapsed_seconds'] = elapsed
report['package_after'] = read('/sys/kernel/debug/pmc_core/package_cstate_show')
report['devices_after'] = devices()
debug_paths = [
    '/sys/kernel/debug/pmc_core/ltr_show',
    '/sys/kernel/debug/pmc_core/lpm_status',
    '/sys/kernel/debug/pmc_core/lpm_requirements',
    '/sys/kernel/debug/dri/0/i915_dmc_info',
    '/sys/kernel/debug/dri/0/i915_power_domain_info',
    '/sys/kernel/debug/dri/0/i915_display_info',
    '/sys/kernel/debug/dri/0/gt0/drpc',
    '/sys/kernel/debug/dri/0/gt1/drpc',
    '/sys/kernel/debug/dri/0/gt1/uc/gsc_info',
]
# Read potentially waking diagnostics after the idle measurement has finished.
report['debug'] = {p: read(p) for p in debug_paths}
try:
    pci = subprocess.run(['lspci', '-vv'], capture_output=True, text=True)
    report['lspci'] = pci.stdout
    report['lspci_errors'] = pci.stderr
except FileNotFoundError:
    report['lspci'] = None
report['nvme_default_ps_max_latency_us'] = read(
    '/sys/module/nvme_core/parameters/default_ps_max_latency_us')
report['nvme_cli_available'] = shutil.which('nvme') is not None
report['nvme_controllers'] = {}
if report['nvme_cli_available']:
    for controller in sorted(Path('/sys/class/nvme').glob('nvme*')):
        device = '/dev/' + controller.name
        report['nvme_controllers'][controller.name] = {
            'pci_path': str((controller / 'device').resolve()),
            'model': read(controller / 'model'),
            'firmware_rev': read(controller / 'firmware_rev'),
            'identify': nvme_command(['id-ctrl', device, '-H']),
            'power_management': nvme_command([
                'get-feature', device, '-f', '0x02', '-s', '0', '-H', '-t', '5000']),
            'autonomous_power_state_transition': nvme_command([
                'get-feature', device, '-f', '0x0c', '-s', '0', '-H', '-t', '5000']),
        }
print(json.dumps(report, indent=2))
